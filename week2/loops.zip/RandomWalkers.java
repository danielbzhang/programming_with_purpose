public class RandomWalkers {
  public static void main(String[] args) {
    int r = Integer.parseInt(args[0]);
    int trials = Integer.parseInt(args[1]);
    int sum = 0, x = 0, y = 0, steps = 0;

    for (int i = 0; i < trials; i++) {
      while (Math.abs(x) + Math.abs(y) < r) {
        double p = Math.random();
        if (p > 0.75) {
          x += 1;
        } else if (p > 0.5) {
          x -= 1;
        } else if (p > 0.25) {
          y += 1;
        } else {
          y -= 1;
        }
        steps++;
      }
      sum += steps;
    }
    double avg = sum / trials;
    System.out.println("average number of steps = " + avg);
  }
}